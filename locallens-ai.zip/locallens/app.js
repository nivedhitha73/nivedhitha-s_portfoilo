const $=s=>document.querySelector(s),LS=localStorage;
const LN={en:'English',te:'తెలుగు',hi:'हिन्दी',ta:'தமிழ்',kn:'ಕನ್ನಡ'},TTS={en:'en-IN',te:'te-IN',hi:'hi-IN',ta:'ta-IN',kn:'kn-IN'};
const J=(k,d)=>{try{return JSON.parse(LS[k])||d}catch(e){return d}};
let langs=J('ll_langs',['en','te','hi']),lang=LS.ll_lang||'en',custom=J('ll_places',[]),cur=null,me=null;
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const all=()=>{const m=new Map(PLACES.map(p=>[p.id,p]));custom.forEach(p=>m.set(p.id,p));return[...m.values()]};
const T=o=>(o&&(o[lang]||o.en))||'';
const km=(a,b,c,d)=>{const r=Math.PI/180,x=Math.sin((c-a)*r/2)**2+Math.cos(a*r)*Math.cos(c*r)*Math.sin((d-b)*r/2)**2;return 12742*Math.asin(Math.sqrt(x))};
const from=(o)=>all().filter(p=>p!==o).sort((a,b)=>km(o.lat,o.lng,a.lat,a.lng)-km(o.lat,o.lng,b.lat,b.lng));
const sorted=()=>me?all().sort((a,b)=>km(me.lat,me.lng,a.lat,a.lng)-km(me.lat,me.lng,b.lat,b.lng)):all();
const dist=p=>me?` · ${km(me.lat,me.lng,p.lat,p.lng).toFixed(1)} km away`:'';
function toast(t){const e=$('#toast');e.textContent=t;e.style.display='block';clearTimeout(toast.t);toast.t=setTimeout(()=>e.style.display='none',4500)}
const db=new Promise(r=>{const q=indexedDB.open('locallens',1);q.onupgradeneeded=()=>q.result.createObjectStore('a');q.onsuccess=()=>r(q.result)});
const idb=async(m,k,v)=>{const d=await db;return new Promise(r=>{const o=d.transaction('a',m=='get'?'readonly':'readwrite').objectStore('a'),q=m=='get'?o.get(k):o.put(v,k);q.onsuccess=()=>r(q.result);q.onerror=()=>r()})};

// Tabs & languages
document.querySelectorAll('#tabs button').forEach(b=>b.onclick=()=>{document.querySelectorAll('#tabs button').forEach(x=>x.classList.toggle('on',x==b));document.querySelectorAll('.tab').forEach(s=>s.hidden=s.id!=b.dataset.t);if(b.dataset.t=='map')drawMap();if(b.dataset.t=='route')drawRoute()});
const show=t=>document.querySelector(`#tabs [data-t=${t}]`).click();
function renderLangs(){$('#langs').innerHTML=langs.map(l=>`<button data-l="${l}" class="${l==lang?'on':''}">${LN[l]||l}</button>`).join('');
 document.querySelectorAll('#langs button').forEach(b=>b.onclick=()=>{lang=b.dataset.l;LS.ll_lang=lang;speechSynthesis.cancel();$('#player').pause();init(true)});
 $('#langFields').innerHTML=langs.map(l=>`<div class="lf"><b>${LN[l]||l}</b><textarea name="info_${l}" placeholder="Description in ${LN[l]||l}"></textarea><label>Audio guide (${LN[l]||l}) <input name="aud_${l}" type="file" accept="audio/*"></label></div>`).join('')}

// Place list & detail
function renderList(){$('#list').innerHTML=sorted().map(p=>`<div class="card ${cur&&cur.id==p.id?'on':''}" data-id="${esc(p.id)}"><i>${esc(p.emoji||'📍')}</i><div><b>${esc(T(p.name))}</b><span>${esc(p.city)}${dist(p)}</span></div></div>`).join('');
 document.querySelectorAll('.card').forEach(c=>c.onclick=()=>select(c.dataset.id))}
function select(id){cur=all().find(p=>p.id==id)||all()[0];renderList();const p=cur,img=p.img||`images/${p.id}.jpg`;
 $('#detail').innerHTML=`<div class="hero">${esc(p.emoji||'📍')}<img src="${esc(img)}" alt="" onerror="this.remove()" style="position:absolute;opacity:0" onload="this.style.cssText='';this.parentNode.firstChild.textContent=''"></div>
<h2>${esc(T(p.name))}</h2><p class="sub">${esc(p.city)}${dist(p)}</p>
<div class="btns"><button class="btn" id="listen">🎧 Listen</button><a class="btn alt" target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&destination=${p.lat},${p.lng}">🗺️ Navigate</a><button class="btn alt" id="goRoute">🧭 Route</button><button class="btn alt" id="next">Next place ➜</button></div>
<h3>📜 History</h3><p>${esc(T(p.info))}</p><p>${esc(p.history)}</p>
<h3>📖 Local stories & legends</h3><p>${esc(p.legend)}</p><h3>🍛 Local food</h3><p>${esc(p.food)}</p><h3>🛍️ Local shopping</h3><p>${esc(p.shop)}</p>`;
 $('.hero').style.position='relative';
 $('#listen').onclick=play;$('#goRoute').onclick=()=>show('route');$('#next').onclick=()=>select(from(p)[0].id)}

// Audio: uploaded file (admin) > audio/<id>-<lang>.mp3 > device voice
async function play(){const p=cur,a=$('#player');speechSynthesis.cancel();a.pause();
 const blob=await idb('get',p.id+'|'+lang);a.src=blob?URL.createObjectURL(blob):`audio/${p.id}-${lang}.mp3`;
 a.onerror=()=>say(T(p.info));a.play().catch(()=>{})}
function say(text){if(!('speechSynthesis' in window))return toast('Audio file not found and this browser has no voice.');
 const u=new SpeechSynthesisUtterance(text);u.lang=TTS[lang]||'en-IN';
 if(!speechSynthesis.getVoices().some(v=>v.lang.toLowerCase().startsWith(lang)))toast(`No ${LN[lang]||lang} voice on this device. Add audio/${cur.id}-${lang}.mp3 to play real audio.`);
 speechSynthesis.speak(u)}

// Location
$('#detect').onclick=()=>{if(!navigator.geolocation)return toast('Location is not available.');
 navigator.geolocation.watchPosition(g=>{const first=!me;me={lat:g.coords.latitude,lng:g.coords.longitude};const n=sorted()[0];
  if(first||(cur&&n.id!=cur.id&&km(me.lat,me.lng,n.lat,n.lng)<0.3))select(n.id);else renderList()},()=>toast('Could not get your location. Pick a place from the list.'),{enableHighAccuracy:true})};

// Map (offline SVG)
const IN=[[68.1,23.6],[70.2,20.9],[72.8,21.1],[72.9,19],[73.8,15.5],[74.8,12.9],[76.2,9.9],[77.5,8.1],[78.2,8.9],[79.8,10.3],[80.3,13.1],[80.3,15.8],[82.3,16.9],[84.8,19.2],[86.9,21.5],[88.9,21.6],[89,22.5],[89.8,26],[92,26.3],[92.5,24.5],[93.5,22.9],[94.5,25.5],[96.1,27.3],[95,29],[92,27.8],[88.8,27.3],[88.5,28],[84,28.7],[81,30.2],[79,31],[78.8,32.8],[77.8,35.5],[75,36.8],[74.3,34.6],[74.5,32.5],[74.3,31],[71,28],[70,26.8],[69.2,24.3]];
const X=o=>((o-67.5)*13.5).toFixed(1),Y=a=>((37.5-a)*13.5).toFixed(1);
function drawMap(){$('#svg').innerHTML=`<path d="M${IN.map(c=>X(c[0])+','+Y(c[1])).join('L')}Z"/>`+all().map(p=>`<circle data-id="${esc(p.id)}" cx="${X(p.lng)}" cy="${Y(p.lat)}" r="${cur&&cur.id==p.id?9:6}" fill="#e36414" stroke="#fff" stroke-width="2"><title>${esc(T(p.name))}</title></circle>`).join('')+(me?`<circle cx="${X(me.lng)}" cy="${Y(me.lat)}" r="6" fill="#1a73e8" stroke="#fff" stroke-width="2"/>`:'');
 document.querySelectorAll('#svg circle[data-id]').forEach(c=>c.onclick=()=>{select(c.dataset.id);show('explore')})}

// Tourist route: place -> next attraction -> local market -> food
function drawRoute(){if(!cur)cur=all()[0];const p=cur,n=from(p)[0],s=[['🏛️',T(p.name),p.city],['🏛️',T(n.name),`${km(p.lat,p.lng,n.lat,n.lng).toFixed(0)} km from ${T(p.name)}`],['🛍️','Local market',p.shop],['🍛','Food stop',p.food]];
 $('#routeBox').innerHTML=`<h2>Route from ${esc(T(p.name))}</h2><p class="sub">Pick another place in Explore to change the route.</p>`+s.map((x,i)=>`<div class="step"><em>${i+1}</em><div><b>${x[0]} ${esc(x[1])}</b><br><span class="sub">${esc(x[2])}</span></div></div>`).join('')}

// AI tourism chatbot (answers from the place database)
function answer(q){const s=q.toLowerCase(),L=all(),p=L.find(x=>(x.k||x.name.en.toLowerCase()).split(' ').some(w=>w.length>3&&s.includes(w)))||cur;
 if(/nearby|near me|around/.test(s)){const o=p||(me&&{lat:me.lat,lng:me.lng});return o?'Nearby places: '+from(o).slice(0,3).map(x=>`${T(x.name)} (${km(o.lat,o.lng,x.lat,x.lng).toFixed(0)} km)`).join(', ')+'.':'Select a place or detect your location first.'}
 if(!p)return 'Tell me a place name, or open one in Explore first.';const n=T(p.name);
 if(/food|eat|dish/.test(s))return `Try ${p.food} near ${n}.`;
 if(/shop|buy|souvenir|handicraft|market/.test(s))return `Near ${n} you can shop for ${p.shop}.`;
 if(/legend|story|myth/.test(s))return p.legend;
 if(/histor|built|who|when/.test(s))return p.history;
 return `${T(p.info)} ${p.legend}`}
$('#chatForm').onsubmit=e=>{e.preventDefault();const q=$('#q').value.trim();if(!q)return;const l=$('#log');
 l.innerHTML+=`<div class="m u">${esc(q)}</div><div class="m b">${esc(answer(q))}</div>`;$('#q').value='';l.scrollTop=l.scrollHeight};

// Admin panel
const rd=f=>new Promise(r=>{const x=new FileReader();x.onload=()=>r(x.result);x.readAsDataURL(f)});
$('#adminForm').onsubmit=async e=>{e.preventDefault();const f=e.target,v=n=>f[n].value.trim(),id=f.dataset.edit||v('name').toLowerCase().replace(/\W+/g,'-'),old=all().find(p=>p.id==id)||{};
 const p={...old,id,emoji:old.emoji||'📍',k:old.k||v('name').toLowerCase(),name:{...old.name,en:v('name')},city:v('city'),lat:+v('lat'),lng:+v('lng'),history:v('history'),legend:v('legend'),food:v('food'),shop:v('shop'),info:{...old.info}};
 for(const l of langs){const t=v('info_'+l);if(t)p.info[l]=t;const a=f['aud_'+l].files[0];if(a)await idb('put',id+'|'+l,a)}
 if(f.img.files[0])p.img=await rd(f.img.files[0]);
 custom=custom.filter(c=>c.id!=id).concat(p);try{LS.ll_places=JSON.stringify(custom)}catch(x){toast('Storage full: use a smaller image.')}
 f.reset();delete f.dataset.edit;toast('Saved: '+p.name.en);init()};
$('#addLang').onclick=()=>{const l=$('#newLang').value;if(!langs.includes(l)){langs.push(l);LS.ll_langs=JSON.stringify(langs)}init()};
function renderAdmin(){$('#adminList').innerHTML=all().map(p=>`<div class="ar"><span>${esc(p.emoji||'📍')} ${esc(p.name.en)}</span><span><button class="btn alt" data-e="${esc(p.id)}">Edit</button> ${custom.some(c=>c.id==p.id)?`<button class="btn" data-d="${esc(p.id)}">Delete custom</button>`:''}</span></div>`).join('');
 document.querySelectorAll('[data-e]').forEach(b=>b.onclick=()=>{const p=all().find(x=>x.id==b.dataset.e),f=$('#adminForm');f.dataset.edit=p.id;
  ['city','lat','lng','history','legend','food','shop'].forEach(k=>f[k].value=p[k]);f.name.value=p.name.en;langs.forEach(l=>f['info_'+l].value=(p.info||{})[l]||'');f.scrollIntoView()});
 document.querySelectorAll('[data-d]').forEach(b=>b.onclick=()=>{custom=custom.filter(c=>c.id!=b.dataset.d);LS.ll_places=JSON.stringify(custom);if(cur&&cur.id==b.dataset.d)cur=null;init()})}

function init(keep){renderLangs();renderAdmin();select(keep&&cur?cur.id:(cur&&all().some(p=>p.id==cur.id)?cur.id:all()[0].id))}
speechSynthesis&&speechSynthesis.getVoices();init();
