Put your audio guide files here, named <place-id>-<language>.mp3
Place ids: venkateswara, tajmahal, charminar, hawamahal, mysorepalace
Languages: en, te, hi (also ta, kn)
Example: venkateswara-te.mp3 = Telugu guide for Sri Venkateswara Temple
Optional photos go in images/ as <place-id>.jpg
If a file is missing, the app reads the description aloud with the device voice.
Places added in the Admin panel use the audio you upload there.
